'''Header
Jeffrey Kim and Nathan Tran 
3.2.7 Data project
Used 3.1.1 as a template'''

#libraries
import os.path
import matplotlib.pyplot as plt
import numpy as np

#initialize the aggregators
coffeelist = []
urbanlist = []

# Open the file
directory = os.path.dirname(os.path.abspath(__file__)) 
filename = os.path.join(directory,'naisu.csv')
datafile = open(filename,'r')

#Open the csv file and grab the data
for line in datafile: 
    state, coffee, urban = line.split(',')
    coffeelist.append(float(coffee))
    urbanlist.append(float(urban))
datafile.close()

#Used to get the linear regression; Credits:DSM of stackoverflow; 
#http://stackoverflow.com/questions/6148207/linear-regression-with-matplotlib-numpy
fit = np.polyfit(urbanlist,coffeelist,1)
fit_fn = np.poly1d(fit) 

# Plot on one set of axes.
fig, ax = plt.subplots(1,1)
ax.scatter(urbanlist,coffeelist,c=urbanlist,s=250)
ax.plot(urbanlist,coffeelist, 'w,', urbanlist, fit_fn(urbanlist)) 
ax.set_title('U.S Urban Rate vs. Coffee Consumption Rate By Every State')
ax.set_xlabel('U.S Urban Rate')
ax.set_ylabel('Coffee Consumption Rate')
ax.axis([30, 100, 40, 100])
fig.show()